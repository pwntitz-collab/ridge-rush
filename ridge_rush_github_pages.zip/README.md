# Ridge Rush v0.2

Browser-based motorbike physics game.

## Publishing with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html` to the repository root.
3. Settings > Pages > Build and deployment: Deploy from a branch; branch `main`, folder `/(root)`; Save.
4. Open `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/` after deployment completes.
